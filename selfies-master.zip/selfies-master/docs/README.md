To build the documentation, please install
* the [sphinx-autotoc-typehints](https://github.com/agronholm/sphinx-autodoc-typehints) extension  
* the [Read the Docs Sphinx theme](https://github.com/readthedocs/sphinx_rtd_theme)
* the [nbsphinx](https://github.com/spatialaudio/nbsphinx) extension

and then run 
```
python -m sphinx source <build-dir>
```
in this directory. 
