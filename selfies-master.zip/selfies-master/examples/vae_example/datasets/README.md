Dataset files with molecules represented in SMILES.
