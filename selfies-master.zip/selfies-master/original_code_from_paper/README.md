This file contains the original code from the SELFIES
[paper](https://arxiv.org/abs/1905.13741). The required dependencies to run 
this code are listed in ``environment.yml``. Note that this code ran on 
an old version of SELFIES (``v0.1.1``).
