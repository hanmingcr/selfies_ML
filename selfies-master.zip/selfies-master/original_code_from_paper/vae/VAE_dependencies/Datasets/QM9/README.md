QM9 representation in SMILES, DeepSMILES, SELFIES, GrammarVAE
